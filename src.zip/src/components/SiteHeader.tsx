import styles from "./SiteHeader.module.css";

export function SiteHeader() {
  return (
    <header className={styles.header}>
      <img
        src="/assets/logo.svg"
        alt="easyfundraising"
        className={styles.logo}
      />
    </header>
  );
}
