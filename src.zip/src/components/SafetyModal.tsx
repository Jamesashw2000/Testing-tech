import { useCallback, useEffect, useRef, useState } from "react";
import styles from "./SafetyModal.module.css";

type SafetyModalProps = {
  isOpen: boolean;
  onClose: () => void;
  causeName?: string;
  userEmail?: string;
};

const ANIMATION_MS = 300;

export function SafetyModal({
  isOpen,
  onClose,
  causeName = "Dog Shelter Chelsea",
  userEmail = "liamdavies@outlook.com",
}: SafetyModalProps) {
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const [isMounted, setIsMounted] = useState(isOpen);
  const [isClosing, setIsClosing] = useState(false);

  const finishClose = useCallback(() => {
    setIsMounted(false);
    setIsClosing(false);
    onClose();
  }, [onClose]);

  const requestClose = useCallback(() => {
    if (isClosing) return;

    const prefersReducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;

    if (prefersReducedMotion) {
      finishClose();
      return;
    }

    setIsClosing(true);
  }, [isClosing, finishClose]);

  useEffect(() => {
    if (!isOpen) return;
    setIsMounted(true);
    setIsClosing(false);
  }, [isOpen]);

  useEffect(() => {
    if (!isMounted) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    if (!isClosing) {
      closeButtonRef.current?.focus();

      function handleKeyDown(event: KeyboardEvent) {
        if (event.key === "Escape") requestClose();
      }

      window.addEventListener("keydown", handleKeyDown);
      return () => {
        document.body.style.overflow = previousOverflow;
        window.removeEventListener("keydown", handleKeyDown);
      };
    }

    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [isMounted, isClosing, requestClose]);

  useEffect(() => {
    if (!isClosing) return;

    const timer = window.setTimeout(finishClose, ANIMATION_MS);
    return () => window.clearTimeout(timer);
  }, [isClosing, finishClose]);

  if (!isMounted) return null;

  const overlayClass = isClosing ? styles.overlayClosing : styles.overlayOpen;
  const dialogClass = isClosing ? styles.dialogClosing : styles.dialogOpen;

  return (
    <div className={overlayClass} onClick={requestClose}>
      <div
        className={`${styles.dialog} ${dialogClass}`}
        role="dialog"
        aria-modal="true"
        aria-labelledby="safety-modal-title"
        onClick={(event) => event.stopPropagation()}
      >
        <header className={styles.header}>
          <button
            ref={closeButtonRef}
            type="button"
            className={styles.closeButton}
            onClick={requestClose}
            aria-label="Close"
          >
            <img
              src="/assets/modal/close-icon.svg"
              alt=""
              className={styles.closeIcon}
              width={16}
              height={16}
            />
          </button>
        </header>

        <div className={styles.body}>
          <div className={styles.content}>
            <div className={styles.mainBlock}>
              <img
                src="/assets/modal/notification-icon.svg"
                alt=""
                className={styles.leadIcon}
                width={40}
                height={40}
              />

              <h2 id="safety-modal-title" className={styles.modalTitle}>
                Every Admin stays in the loop!
              </h2>

              <p className={styles.modalDescription}>
                Whenever a change is made to {causeName}, all Admins, including
                yourself, are notified via email.
              </p>

              <div className={styles.emailBox}>
                <p className={styles.emailBoxLabel}>
                  You&rsquo;ll receive email notifications at:
                </p>
                <p className={styles.emailBoxValue}>{userEmail}</p>
              </div>
            </div>

            <div className={styles.securityBox}>
              <img
                src="/assets/modal/stamp-icon.svg"
                alt=""
                className={styles.stampIcon}
                width={20}
                height={20}
              />
              <p className={styles.securityTitle}>
                We double check all sensitive updates.
              </p>
              <p className={styles.securityText}>
                For changes to payment details and cause deletion requests, we
                don&rsquo;t just notify you, our Support Team personally reviews
                and verifies every request before it&rsquo;s processed.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
