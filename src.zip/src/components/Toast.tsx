import styles from "./Toast.module.css";

type ToastProps = {
  message: string;
  onClose: () => void;
};

export function Toast({ message, onClose }: ToastProps) {
  return (
    <div className={styles.toast} role="status" aria-live="polite">
      <div className={styles.content}>
        <span className={styles.icon} aria-hidden="true">
          ✓
        </span>
        <p className={styles.message}>{message}</p>
      </div>
      <button
        type="button"
        className={styles.close}
        onClick={onClose}
        aria-label="Dismiss notification"
      >
        ×
      </button>
    </div>
  );
}
