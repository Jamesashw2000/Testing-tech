import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import { AdminEntry } from "../components/AdminEntry";
import { InviteButton } from "../components/InviteButton";
import { SiteHeader } from "../components/SiteHeader";
import { SafetyModal } from "../components/SafetyModal";
import { Toast } from "../components/Toast";
import styles from "./BuildAdminTeam.module.css";

type InvitedAdmin = {
  email: string;
};

const CURRENT_USER = { name: "Liam D." };
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function BuildAdminTeam() {
  const [email, setEmail] = useState("");
  const [invited, setInvited] = useState<InvitedAdmin[]>([]);
  const [loading, setLoading] = useState(false);
  const [toastEmail, setToastEmail] = useState<string | null>(null);
  const [safetyModalOpen, setSafetyModalOpen] = useState(false);

  const trimmedEmail = email.trim();
  const canInvite = EMAIL_PATTERN.test(trimmedEmail) && !loading;

  useEffect(() => {
    if (!toastEmail) return;
    const timer = window.setTimeout(() => setToastEmail(null), 5000);
    return () => window.clearTimeout(timer);
  }, [toastEmail]);

  async function handleInvite() {
    if (!canInvite) return;

    const normalizedEmail = trimmedEmail.toLowerCase();
    const alreadyInvited = invited.some(
      (person) => person.email.toLowerCase() === normalizedEmail,
    );

    setLoading(true);
    await new Promise((resolve) => window.setTimeout(resolve, 1200));

    if (!alreadyInvited) {
      setInvited((prev) => [...prev, { email: trimmedEmail }]);
    }

    setEmail("");
    setToastEmail(trimmedEmail);
    setLoading(false);
  }

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    void handleInvite();
  }

  return (
    <div className={styles.page}>
      <SiteHeader />

      <main className={styles.content}>
        <section className={styles.copy}>
          <h1 className={styles.title}>Let&rsquo;s build your Admin Team</h1>
          <p className={styles.description}>
            Invite trusted people to your Admin Team. They&rsquo;ll have the same
            access as you, so they can help manage and grow your cause.
          </p>
          <button
            type="button"
            className={styles.safetyLink}
            onClick={() => setSafetyModalOpen(true)}
          >
            See how we keep your cause safe
          </button>
        </section>

        <form className={styles.inviteForm} onSubmit={handleSubmit}>
          <label className={styles.fieldLabel} htmlFor="admin-email">
            <input
              id="admin-email"
              type="email"
              className={styles.input}
              placeholder="Add an email address"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              autoComplete="email"
              disabled={loading}
            />
          </label>
          <InviteButton
            loading={loading}
            disabled={!canInvite}
            onClick={() => void handleInvite()}
          />
        </form>

        <section className={styles.adminList} aria-label="Admin team members">
          <AdminEntry
            name={CURRENT_USER.name}
            isYou
            badge={{ label: "Admin", variant: "admin" }}
            avatarVariant="warm"
          />

          {invited.map((person) => (
            <div key={person.email} className={styles.listBlock}>
              <hr className={styles.divider} />
              <AdminEntry
                name={person.email}
                badge={{ label: "Invite sent", variant: "invite-sent" }}
                avatarVariant="neutral"
              />
            </div>
          ))}

          {invited.length === 0 && <hr className={styles.divider} />}
        </section>

        <div className={styles.skipLinkWrap}>
          <a href="#skip" className={styles.skipLink}>
            Add another admin later
          </a>
        </div>
      </main>

      {toastEmail && (
        <Toast
          message={`You sent ${toastEmail} an invite`}
          onClose={() => setToastEmail(null)}
        />
      )}

      <SafetyModal
        isOpen={safetyModalOpen}
        onClose={() => setSafetyModalOpen(false)}
      />
    </div>
  );
}
