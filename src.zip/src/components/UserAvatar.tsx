import styles from "./UserAvatar.module.css";

type UserAvatarProps = {
  variant?: "warm" | "neutral";
};

export function UserAvatar({ variant = "warm" }: UserAvatarProps) {
  const src =
    variant === "neutral"
      ? "/assets/avatar-neutral.png"
      : "/assets/avatar-warm.png";

  return (
    <img
      src={src}
      alt=""
      className={styles.avatar}
      width={48}
      height={48}
      aria-hidden="true"
    />
  );
}
