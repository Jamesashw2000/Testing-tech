import { UserAvatar } from "./UserAvatar";
import styles from "./AdminEntry.module.css";

type AdminEntryProps = {
  name: string;
  isYou?: boolean;
  badge: { label: string; variant: "admin" | "invite-sent" };
  avatarVariant?: "warm" | "neutral";
};

export function AdminEntry({
  name,
  isYou = false,
  badge,
  avatarVariant = "warm",
}: AdminEntryProps) {
  return (
    <div className={styles.entry}>
      <div className={styles.user}>
        <UserAvatar variant={avatarVariant} />
        <div className={styles.details}>
          <div className={styles.nameRow}>
            <span className={styles.name}>{name}</span>
            {isYou && (
              <span className={styles.youWrap}>
                <img
                  src="/assets/highlight-you.svg"
                  alt=""
                  className={styles.youHighlight}
                />
                <span className={styles.youText}>(you)</span>
              </span>
            )}
          </div>
        </div>
      </div>
      <span
        className={`${styles.tag} ${
          badge.variant === "admin" ? styles.tagAdmin : styles.tagInviteSent
        }`}
      >
        {badge.label}
      </span>
    </div>
  );
}
