import styles from "./InviteButton.module.css";

type InviteButtonProps = {
  loading?: boolean;
  disabled?: boolean;
  onClick: () => void;
};

export function InviteButton({ loading = false, disabled = false, onClick }: InviteButtonProps) {
  return (
    <button
      type="button"
      className={styles.button}
      onClick={onClick}
      disabled={disabled || loading}
      aria-busy={loading}
    >
      {loading ? <span className={styles.spinner} aria-hidden="true" /> : "Invite"}
    </button>
  );
}
