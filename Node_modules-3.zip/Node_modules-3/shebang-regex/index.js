'use strict';
module.exports = /^#!(.*)/;
