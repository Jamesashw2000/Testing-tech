import { BuildAdminTeam } from "./pages/BuildAdminTeam";
import "./styles/global.css";

function App() {
  return <BuildAdminTeam />;
}

export default App;
